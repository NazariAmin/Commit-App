//
//  Commit+CoreDataProperties.swift
//  CommitApp
//
//  Created by Nazari on 2/15/17.
//  Copyright © 2017 Puia. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


extension Commit {

    @nonobjc public class func createFetchRequest() -> NSFetchRequest<Commit> {
        return NSFetchRequest<Commit>(entityName: "Commit");
    }

    @NSManaged public var attribute: Date
    @NSManaged public var message: String
    @NSManaged public var sha: String
    @NSManaged public var url: String

}
