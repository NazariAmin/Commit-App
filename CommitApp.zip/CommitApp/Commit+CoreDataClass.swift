//
//  Commit+CoreDataClass.swift
//  CommitApp
//
//  Created by Nazari on 2/15/17.
//  Copyright © 2017 Puia. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(Commit)
public class Commit: NSManagedObject {

}
